import os
import sqlite3
import hashlib
import re
import ast
from flask import Flask, render_template, request, jsonify, session, redirect, url_for
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.secret_key = 'ai-code-review-assistant-final-year-project'
app.config['UPLOAD_FOLDER'] = 'uploads/'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size

# Create uploads directory if it doesn't exist
if not os.path.exists(app.config['UPLOAD_FOLDER']):
    os.makedirs(app.config['UPLOAD_FOLDER'])

# ==================== AUTHENTICATION SYSTEM ====================
class AuthSystem:
    def __init__(self, db_path='users.db'):
        self.db_path = db_path
        self.init_db()
    
    def init_db(self):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                email TEXT UNIQUE NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        conn.commit()
        conn.close()
    
    def hash_password(self, password):
        return hashlib.sha256(password.encode()).hexdigest()
    
    def register(self, username, password, email):
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Validate input
            if len(username) < 3:
                return {'success': False, 'error': 'Username must be at least 3 characters'}
            if len(password) < 6:
                return {'success': False, 'error': 'Password must be at least 6 characters'}
            
            password_hash = self.hash_password(password)
            cursor.execute(
                'INSERT INTO users (username, password_hash, email) VALUES (?, ?, ?)',
                (username, password_hash, email)
            )
            conn.commit()
            conn.close()
            return {'success': True, 'message': 'Registration successful'}
        except sqlite3.IntegrityError:
            return {'success': False, 'error': 'Username or email already exists'}
        except Exception as e:
            return {'success': False, 'error': f'Registration failed: {str(e)}'}
    
    def authenticate(self, username, password):
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            cursor.execute(
                'SELECT * FROM users WHERE username = ? AND password_hash = ?',
                (username, self.hash_password(password))
            )
            user = cursor.fetchone()
            conn.close()
            
            if user:
                return {'id': user[0], 'username': user[1], 'email': user[3]}
            return None
        except Exception as e:
            print(f"Authentication error: {e}")
            return None

# ==================== CODE ANALYZER ====================
class CodeAnalyzer:
    def __init__(self):
        self.bug_patterns = {
            'undefined_variable': r'NameError|undefined',
            'type_error': r'TypeError|type mismatch',
            'syntax_error': r'SyntaxError|invalid syntax',
            'index_error': r'IndexError|out of range',
            'key_error': r'KeyError|not found'
        }
    
    def detect_bugs(self, code):
        bugs = []
        
        # Syntax check
        try:
            ast.parse(code)
        except SyntaxError as e:
            bugs.append({
                'type': 'Syntax Error',
                'line': e.lineno if hasattr(e, 'lineno') else 1,
                'message': str(e),
                'severity': 'high'
            })
            return bugs  # Return early if syntax error
        
        # Common bug patterns
        lines = code.split('\n')
        for i, line in enumerate(lines, 1):
            line = line.strip()
            if not line or line.startswith('#'):
                continue
                
            # Check for potential division by zero
            if re.search(r'/\s*0', line) and '//' not in line and '/*' not in line:
                bugs.append({
                    'type': 'Potential Division by Zero',
                    'line': i,
                    'message': 'Division by zero may cause runtime error',
                    'severity': 'high'
                })
            
            # Check for unused variables (simplified)
            if '=' in line and not any(x in line for x in ['==', '!=', '>=', '<=']):
                parts = line.split('=')
                if len(parts) > 1:
                    var_name = parts[0].strip()
                    # Simple check if variable is used later
                    if var_name and var_name.isidentifier():
                        later_code = '\n'.join(lines[i:])
                        if var_name not in later_code:
                            bugs.append({
                                'type': 'Unused Variable',
                                'line': i,
                                'message': f'Variable "{var_name}" is assigned but not used',
                                'severity': 'low'
                            })
        
        return bugs
    
    def assess_quality(self, code):
        quality_metrics = {
            'score': 100,
            'issues': [],
            'suggestions': []
        }
        
        lines = [line for line in code.split('\n') if line.strip() and not line.strip().startswith('#')]
        
        if not lines:
            quality_metrics['score'] = 0
            quality_metrics['issues'].append({'type': 'Empty code', 'line': 0, 'message': 'No code to analyze'})
            return quality_metrics
        
        # Line length check
        for i, line in enumerate(lines, 1):
            if len(line) > 79:
                quality_metrics['score'] -= 1
                quality_metrics['issues'].append({
                    'type': 'Line too long',
                    'line': i,
                    'message': f'Line exceeds 79 characters ({len(line)})'
                })
        
        # Basic structure analysis
        try:
            tree = ast.parse(code)
            # Count functions and classes
            functions = [node for node in ast.walk(tree) if isinstance(node, ast.FunctionDef)]
            classes = [node for node in ast.walk(tree) if isinstance(node, ast.ClassDef)]
            
            if len(functions) == 0 and len(classes) == 0:
                quality_metrics['suggestions'].append('Consider organizing code into functions or classes')
            
            # Complexity analysis
            complexity_nodes = len([node for node in ast.walk(tree) if isinstance(node, (ast.If, ast.While, ast.For))])
            if complexity_nodes > 10:
                quality_metrics['score'] -= min(20, complexity_nodes)
                quality_metrics['suggestions'].append('Consider breaking down complex logic into smaller functions')
                
        except SyntaxError:
            pass  # Already handled in bug detection
        
        # Ensure score doesn't go below 0
        quality_metrics['score'] = max(0, quality_metrics['score'])
        
        return quality_metrics

# ==================== SECURITY SCANNER ====================
class SecurityScanner:
    def __init__(self):
        self.vulnerability_patterns = {
            'sql_injection': [
                r"execute\s*\(.*\+.*",
                r"executemany\s*\(.*\+.*"
            ],
            'xss': [
                r"print\s*\(.*\+.*request",
                r"echo\s+.*\$.*"
            ],
            'hardcoded_secrets': [
                r"password\s*=\s*['\"][^'\"]+['\"]",
                r"api_key\s*=\s*['\"][^'\"]+['\"]",
                r"secret\s*=\s*['\"][^'\"]+['\"]"
            ],
            'eval_usage': [
                r"eval\s*\(",
                r"exec\s*\("
            ],
            'shell_injection': [
                r"os\.system\s*\(",
                r"subprocess\.call\s*\(",
                r"subprocess\.Popen\s*\("
            ]
        }
    
    def scan(self, code):
        vulnerabilities = []
        
        for vuln_type, patterns in self.vulnerability_patterns.items():
            for pattern in patterns:
                try:
                    matches = re.finditer(pattern, code, re.IGNORECASE)
                    for match in matches:
                        line_no = code[:match.start()].count('\n') + 1
                        vulnerabilities.append({
                            'type': vuln_type.replace('_', ' ').title(),
                            'line': line_no,
                            'message': self.get_vulnerability_message(vuln_type),
                            'severity': self.get_severity(vuln_type),
                            'code_snippet': match.group(0)[:100]  # Limit snippet length
                        })
                except re.error:
                    continue  # Skip invalid regex patterns
        
        return vulnerabilities
    
    def get_vulnerability_message(self, vuln_type):
        messages = {
            'sql_injection': 'Potential SQL injection vulnerability detected',
            'xss': 'Potential Cross-site scripting vulnerability',
            'hardcoded_secrets': 'Hardcoded secrets detected - consider using environment variables',
            'eval_usage': 'Use of eval() function can be dangerous - avoid executing dynamic code',
            'shell_injection': 'Potential shell injection vulnerability - validate and sanitize inputs'
        }
        return messages.get(vuln_type, 'Security issue detected')
    
    def get_severity(self, vuln_type):
        severity_map = {
            'sql_injection': 'high',
            'xss': 'high',
            'shell_injection': 'high',
            'hardcoded_secrets': 'medium',
            'eval_usage': 'medium'
        }
        return severity_map.get(vuln_type, 'low')

# ==================== OPTIMIZATION ENGINE ====================
class OptimizationEngine:
    def __init__(self):
        self.optimization_patterns = {
            'loop_optimization': [
                (r'for\s+\w+\s+in\s+range\(len\((\w+)\)\):', 
                 'Use "for item in list:" instead of indexing for better readability'),
                (r'while\s+True:\s*break', 'Consider using for loops with proper conditions')
            ],
            'string_optimization': [
                (r'(\w+)\s*=\s*""\s*for.*in.*(\w+)\s*(\w+)\s*=\s*\2\s*\+\s*\3', 
                 'Use str.join() for string concatenation in loops for better performance')
            ],
            'memory_optimization': [
                (r'list\(\)', 'Use [] for empty lists - more Pythonic and faster'),
                (r'dict\(\)', 'Use {} for empty dictionaries - more Pythonic and faster')
            ],
            'code_smell': [
                (r'if\s+(\w+)\s*==\s*True', 'Use "if variable:" instead of "if variable == True"'),
                (r'if\s+(\w+)\s*==\s*False', 'Use "if not variable:" instead of "if variable == False"')
            ]
        }
    
    def suggest_optimizations(self, code):
        optimizations = []
        
        for opt_type, patterns in self.optimization_patterns.items():
            for pattern, suggestion in patterns:
                try:
                    matches = re.finditer(pattern, code)
                    for match in matches:
                        line_no = code[:match.start()].count('\n') + 1
                        optimizations.append({
                            'type': opt_type.replace('_', ' ').title(),
                            'line': line_no,
                            'suggestion': suggestion,
                            'code_snippet': match.group(0),
                            'severity': 'info'
                        })
                except re.error:
                    continue
        
        return optimizations

# ==================== INITIALIZE COMPONENTS ====================
auth_system = AuthSystem()
code_analyzer = CodeAnalyzer()
security_scanner = SecurityScanner()
optimizer = OptimizationEngine()

# ==================== HTML TEMPLATES ====================
BASE_HTML = '''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AI Code Review Assistant</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); 
            min-height: 100vh;
            padding: 20px;
        }
        .container { 
            max-width: 1200px; 
            margin: 0 auto;
        }
        .login-container { 
            display: flex; 
            justify-content: center; 
            align-items: center; 
            min-height: 80vh; 
        }
        .login-form { 
            background: white; 
            padding: 40px; 
            border-radius: 15px; 
            box-shadow: 0 15px 35px rgba(0,0,0,0.1); 
            width: 100%; 
            max-width: 450px;
            transition: transform 0.3s ease;
        }
        .login-form:hover {
            transform: translateY(-5px);
        }
        .login-form h2 { 
            text-align: center; 
            margin-bottom: 30px; 
            color: #333;
            font-weight: 300;
            font-size: 28px;
        }
        .form-group { 
            margin-bottom: 25px; 
        }
        .form-group input { 
            width: 100%; 
            padding: 15px; 
            border: 2px solid #e1e5e9; 
            border-radius: 8px; 
            font-size: 16px; 
            transition: border-color 0.3s;
        }
        .form-group input:focus {
            border-color: #667eea;
            outline: none;
        }
        button { 
            width: 100%; 
            padding: 15px; 
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); 
            color: white; 
            border: none; 
            border-radius: 8px; 
            font-size: 16px; 
            cursor: pointer; 
            transition: transform 0.2s;
        }
        button:hover { 
            transform: scale(1.02);
        }
        header { 
            background: white; 
            padding: 25px; 
            border-radius: 15px; 
            margin-bottom: 25px; 
            display: flex; 
            justify-content: space-between; 
            align-items: center;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        header h1 {
            color: #333;
            font-weight: 300;
        }
        .dashboard { 
            background: white; 
            padding: 30px; 
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        .code-input textarea { 
            width: 100%; 
            height: 300px; 
            padding: 20px; 
            border: 2px solid #e1e5e9; 
            border-radius: 10px; 
            font-family: 'Courier New', monospace; 
            font-size: 14px; 
            resize: vertical;
            transition: border-color 0.3s;
        }
        .code-input textarea:focus {
            border-color: #667eea;
            outline: none;
        }
        .upload-section { 
            margin: 25px 0; 
            display: flex; 
            gap: 15px; 
            align-items: center;
            flex-wrap: wrap;
        }
        .upload-section input[type="file"] {
            padding: 10px;
            border: 2px dashed #ddd;
            border-radius: 8px;
            flex-grow: 1;
        }
        .upload-section button {
            width: auto;
            padding: 12px 30px;
        }
        .results-container { 
            margin-top: 30px; 
        }
        .issue-card { 
            background: #f8f9fa; 
            border-left: 5px solid #dc3545; 
            padding: 20px; 
            margin: 15px 0; 
            border-radius: 8px;
            transition: transform 0.2s;
        }
        .issue-card:hover {
            transform: translateX(5px);
        }
        .issue-card.low { border-left-color: #28a745; }
        .issue-card.medium { border-left-color: #ffc107; }
        .issue-card.high { border-left-color: #dc3545; }
        .issue-card.info { border-left-color: #17a2b8; }
        .message { 
            padding: 15px; 
            margin: 15px 0; 
            border-radius: 8px; 
            font-weight: 500;
        }
        .error { background: #f8d7da; color: #721c24; border-left: 5px solid #dc3545; }
        .success { background: #d4edda; color: #155724; border-left: 5px solid #28a745; }
        .analysis-options { 
            margin-bottom: 25px; 
            padding: 20px;
            background: #f8f9fa;
            border-radius: 10px;
        }
        .analysis-options select { 
            padding: 12px; 
            border: 2px solid #e1e5e9; 
            border-radius: 8px; 
            font-size: 16px;
            width: 100%;
            max-width: 300px;
        }
        .user-info {
            color: #666;
        }
        .user-info a {
            color: #667eea;
            text-decoration: none;
            margin-left: 15px;
            padding: 8px 15px;
            border: 1px solid #667eea;
            border-radius: 5px;
            transition: all 0.3s;
        }
        .user-info a:hover {
            background: #667eea;
            color: white;
        }
        .stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin: 20px 0;
        }
        .stat-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
            border-radius: 10px;
            text-align: center;
        }
        @media (max-width: 768px) {
            .upload-section {
                flex-direction: column;
            }
            .upload-section button {
                width: 100%;
            }
            header {
                flex-direction: column;
                gap: 15px;
                text-align: center;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        {% block content %}{% endblock %}
    </div>
    <script>
        function setupAuthForms() {
            const showRegister = document.getElementById('showRegister');
            const showLogin = document.getElementById('showLogin');
            
            if (showRegister) {
                showRegister.addEventListener('click', function(e) {
                    e.preventDefault();
                    document.getElementById('loginForm').style.display = 'none';
                    document.getElementById('registerForm').style.display = 'block';
                });
            }
            
            if (showLogin) {
                showLogin.addEventListener('click', function(e) {
                    e.preventDefault();
                    document.getElementById('registerForm').style.display = 'none';
                    document.getElementById('loginForm').style.display = 'block';
                });
            }
            
            const loginForm = document.getElementById('loginForm');
            if (loginForm) {
                loginForm.addEventListener('submit', async function(e) {
                    e.preventDefault();
                    const formData = new FormData(this);
                    const button = this.querySelector('button');
                    const originalText = button.textContent;
                    
                    button.textContent = 'Logging in...';
                    button.disabled = true;
                    
                    try {
                        const response = await fetch('/login', {
                            method: 'POST',
                            body: formData
                        });
                        const result = await response.json();
                        
                        if (result.success) {
                            showMessage('Login successful! Redirecting...', 'success');
                            setTimeout(() => {
                                window.location.href = result.redirect;
                            }, 1000);
                        } else {
                            showMessage(result.error, 'error');
                        }
                    } catch (error) {
                        showMessage('Login failed: ' + error.message, 'error');
                    } finally {
                        button.textContent = originalText;
                        button.disabled = false;
                    }
                });
            }
            
            const registerForm = document.getElementById('registerForm');
            if (registerForm) {
                registerForm.addEventListener('submit', async function(e) {
                    e.preventDefault();
                    const formData = new FormData(this);
                    const button = this.querySelector('button');
                    const originalText = button.textContent;
                    
                    button.textContent = 'Registering...';
                    button.disabled = true;
                    
                    try {
                        const response = await fetch('/register', {
                            method: 'POST',
                            body: formData
                        });
                        const result = await response.json();
                        
                        if (result.success) {
                            showMessage(result.message, 'success');
                            setTimeout(() => {
                                document.getElementById('registerForm').style.display = 'none';
                                document.getElementById('loginForm').style.display = 'block';
                            }, 2000);
                        } else {
                            showMessage(result.error, 'error');
                        }
                    } catch (error) {
                        showMessage('Registration failed: ' + error.message, 'error');
                    } finally {
                        button.textContent = originalText;
                        button.disabled = false;
                    }
                });
            }
        }

        async function analyzeCode() {
            const codeInput = document.getElementById('codeInput');
            const codeFile = document.getElementById('codeFile');
            const analysisType = document.getElementById('analysisType').value;
            const button = document.querySelector('.upload-section button');
            const originalText = button.textContent;
            
            button.textContent = 'Analyzing...';
            button.disabled = true;
            
            const formData = new FormData();
            formData.append('analysis_type', analysisType);
            
            if (codeFile && codeFile.files.length > 0) {
                formData.append('file', codeFile.files[0]);
            } else if (codeInput && codeInput.value.trim()) {
                formData.append('code', codeInput.value);
            } else {
                showMessage('Please enter code or upload a file', 'error');
                button.textContent = originalText;
                button.disabled = false;
                return;
            }
            
            try {
                const response = await fetch('/analyze', {
                    method: 'POST',
                    body: formData
                });
                const results = await response.json();
                displayResults(results);
            } catch (error) {
                showMessage('Analysis failed: ' + error.message, 'error');
            } finally {
                button.textContent = originalText;
                button.disabled = false;
            }
        }

        function displayResults(results) {
            const resultsContainer = document.getElementById('results');
            if (!resultsContainer) return;
            
            resultsContainer.innerHTML = '<h3>📊 Analysis Results</h3>';
            
            if (results.error) {
                showMessage(results.error, 'error');
                return;
            }
            
            let totalIssues = 0;
            if (results.bugs) totalIssues += results.bugs.length;
            if (results.security) totalIssues += results.security.length;
            if (results.optimization) totalIssues += results.optimization.length;
            if (results.quality && results.quality.issues) totalIssues += results.quality.issues.length;
            
            // Display statistics
            resultsContainer.innerHTML += `
                <div class="stats">
                    <div class="stat-card">
                        <h4>Total Issues</h4>
                        <p style="font-size: 2em; margin: 10px 0;">${totalIssues}</p>
                    </div>
                    <div class="stat-card">
                        <h4>Quality Score</h4>
                        <p style="font-size: 2em; margin: 10px 0;">${results.quality ? results.quality.score : 'N/A'}/100</p>
                    </div>
                </div>
            `;
            
            // Display bugs
            if (results.bugs && results.bugs.length > 0) {
                displayIssues(results.bugs, '🐛 Bugs Detected');
            } else if (results.bugs) {
                resultsContainer.innerHTML += '<div class="issue-card info"><strong>✅ No bugs detected!</strong></div>';
            }
            
            // Display security issues
            if (results.security && results.security.length > 0) {
                displayIssues(results.security, '🔒 Security Issues');
            } else if (results.security) {
                resultsContainer.innerHTML += '<div class="issue-card info"><strong>✅ No security issues found!</strong></div>';
            }
            
            // Display quality assessment
            if (results.quality) {
                displayQualityResults(results.quality);
            }
            
            // Display optimization suggestions
            if (results.optimization && results.optimization.length > 0) {
                displayIssues(results.optimization, '⚡ Optimization Suggestions');
            } else if (results.optimization) {
                resultsContainer.innerHTML += '<div class="issue-card info"><strong>✅ Code is well optimized!</strong></div>';
            }
        }

        function displayIssues(issues, title) {
            const container = document.getElementById('results');
            container.innerHTML += `<h4>${title}</h4>`;
            
            issues.forEach(issue => {
                const issueCard = document.createElement('div');
                issueCard.className = `issue-card ${issue.severity}`;
                issueCard.innerHTML = `
                    <strong>${issue.type}</strong> (Line ${issue.line})
                    <p>${issue.message || issue.suggestion}</p>
                    ${issue.code_snippet ? `<code style="display: block; background: #e9ecef; padding: 10px; margin: 10px 0; border-radius: 5px; font-family: monospace;">${issue.code_snippet}</code>` : ''}
                `;
                container.appendChild(issueCard);
            });
        }

        function displayQualityResults(quality) {
            const container = document.getElementById('results');
            const scoreColor = quality.score >= 80 ? '#28a745' : quality.score >= 60 ? '#ffc107' : '#dc3545';
            
            container.innerHTML += `
                <h4>📈 Code Quality Assessment</h4>
                <div class="issue-card info">
                    <strong style="color: ${scoreColor};">Quality Score: ${quality.score}/100</strong>
                    <div style="margin-top: 15px;">
                        ${quality.issues && quality.issues.length > 0 ? 
                            '<strong>Issues:</strong><ul style="margin: 10px 0; padding-left: 20px;">' + 
                            quality.issues.map(issue => `<li>Line ${issue.line}: ${issue.message}</li>`).join('') + 
                            '</ul>' : 
                            '<p>✅ No quality issues found!</p>'
                        }
                        ${quality.suggestions && quality.suggestions.length > 0 ? 
                            '<strong>Suggestions:</strong><ul style="margin: 10px 0; padding-left: 20px;">' + 
                            quality.suggestions.map(suggestion => `<li>${suggestion}</li>`).join('') + 
                            '</ul>' : 
                            ''
                        }
                    </div>
                </div>
            `;
        }

        function showMessage(message, type) {
            // Remove existing messages
            const existingMessage = document.getElementById('message');
            if (existingMessage) {
                existingMessage.remove();
            }
            
            const messageDiv = document.createElement('div');
            messageDiv.id = 'message';
            messageDiv.className = `message ${type}`;
            messageDiv.textContent = message;
            
            const container = document.querySelector('.container');
            if (container) {
                container.insertBefore(messageDiv, container.firstChild);
                
                // Auto-remove after 5 seconds
                setTimeout(() => {
                    if (messageDiv.parentNode) {
                        messageDiv.remove();
                    }
                }, 5000);
            }
        }

        // File upload handler
        function setupFileUpload() {
            const fileInput = document.getElementById('codeFile');
            const codeInput = document.getElementById('codeInput');
            
            if (fileInput && codeInput) {
                fileInput.addEventListener('change', function(e) {
                    const file = e.target.files[0];
                    if (file) {
                        const reader = new FileReader();
                        reader.onload = function(e) {
                            codeInput.value = e.target.result;
                        };
                        reader.readAsText(file);
                    }
                });
            }
        }

        // Initialize when page loads
        document.addEventListener('DOMContentLoaded', function() {
            setupAuthForms();
            setupFileUpload();
        });
    </script>
</body>
</html>'''

LOGIN_HTML = '''<div class="login-container">
    <div class="login-form">
        <h2>AI Code Review Assistant</h2>
        <form id="loginForm">
            <div class="form-group">
                <input type="text" id="username" name="username" placeholder="Username" required>
            </div>
            <div class="form-group">
                <input type="password" id="password" name="password" placeholder="Password" required>
            </div>
            <button type="submit">Login</button>
        </form>
        <p style="text-align: center; margin: 20px 0;">Don't have an account? <a href="#" id="showRegister" style="color: #667eea;">Register</a></p>
        
        <form id="registerForm" style="display: none;">
            <div class="form-group">
                <input type="text" name="username" placeholder="Username" required>
            </div>
            <div class="form-group">
                <input type="email" name="email" placeholder="Email" required>
            </div>
            <div class="form-group">
                <input type="password" name="password" placeholder="Password" required>
            </div>
            <button type="submit">Register</button>
            <p style="text-align: center; margin: 20px 0;">Already have an account? <a href="#" id="showLogin" style="color: #667eea;">Login</a></p>
        </form>
        
        <div id="message"></div>
    </div>
</div>'''

DASHBOARD_HTML = '''<header>
    <h1>AI Code Review Assistant</h1>
    <div class="user-info">
        Welcome, {{ username }}! <a href="{{ url_for('logout') }}">Logout</a>
    </div>
</header>

<div class="dashboard">
    <div class="analysis-options">
        <h3>Code Analysis Options</h3>
        <select id="analysisType">
            <option value="all">Complete Analysis</option>
            <option value="bugs">Bug Detection Only</option>
            <option value="security">Security Analysis Only</option>
            <option value="quality">Quality Assessment Only</option>
            <option value="optimization">Optimization Suggestions</option>
        </select>
    </div>

    <div class="code-input">
        <textarea id="codeInput" placeholder="Paste your Python code here... OR upload a file below"></textarea>
        <div class="upload-section">
            <input type="file" id="codeFile" accept=".py,.txt,.json,.html,.js,.css">
            <button onclick="analyzeCode()">Analyze Code</button>
        </div>
    </div>

    <div id="results" class="results-container"></div>
</div>'''

# ==================== FLASK ROUTES ====================
@app.route('/')
def index():
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '').strip()
        
        if not username or not password:
            return jsonify({'success': False, 'error': 'Username and password are required'})
        
        user = auth_system.authenticate(username, password)
        if user:
            session['user_id'] = user['id']
            session['username'] = user['username']
            return jsonify({'success': True, 'redirect': url_for('dashboard')})
        return jsonify({'success': False, 'error': 'Invalid credentials'})
    
    # GET request - show login page
    html = BASE_HTML.replace('{% block content %}{% endblock %}', LOGIN_HTML)
    return html

@app.route('/register', methods=['POST'])
def register():
    username = request.form.get('username', '').strip()
    password = request.form.get('password', '').strip()
    email = request.form.get('email', '').strip()
    
    if not username or not password or not email:
        return jsonify({'success': False, 'error': 'All fields are required'})
    
    result = auth_system.register(username, password, email)
    return jsonify(result)

@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    username = session.get('username', 'User')
    html = BASE_HTML.replace('{% block content %}{% endblock %}', 
                            DASHBOARD_HTML.replace('{{ username }}', username))
    return html

@app.route('/analyze', methods=['POST'])
def analyze_code():
    if 'user_id' not in session:
        return jsonify({'error': 'Please login first'})
    
    code = request.form.get('code', '').strip()
    file = request.files.get('file')
    analysis_type = request.form.get('analysis_type', 'all')
    
    try:
        if file and file.filename:
            # Validate file type
            if not file.filename.lower().endswith(('.py', '.txt', '.json', '.html', '.js', '.css')):
                return jsonify({'error': 'Invalid file type. Please upload Python, text, or web files.'})
            
            filename = secure_filename(file.filename)
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(filepath)
            with open(filepath, 'r', encoding='utf-8') as f:
                code = f.read()
            # Clean up uploaded file
            os.remove(filepath)
        
        if not code:
            return jsonify({'error': 'No code provided. Please paste code or upload a file.'})
        
        if len(code) > 100000:  # Limit code size to 100KB
            return jsonify({'error': 'Code size too large. Please upload code less than 100KB.'})
        
        results = {}
        
        # Perform analysis based on selected type
        if analysis_type in ['all', 'bugs']:
            results['bugs'] = code_analyzer.detect_bugs(code)
        
        if analysis_type in ['all', 'security']:
            results['security'] = security_scanner.scan(code)
        
        if analysis_type in ['all', 'quality']:
            results['quality'] = code_analyzer.assess_quality(code)
        
        if analysis_type in ['all', 'optimization']:
            results['optimization'] = optimizer.suggest_optimizations(code)
        
        return jsonify(results)
        
    except Exception as e:
        return jsonify({'error': f'Analysis failed: {str(e)}'})

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

@app.errorhandler(413)
def too_large(e):
    return jsonify({'error': 'File too large. Please upload files smaller than 16MB.'}), 413

@app.errorhandler(500)
def internal_error(e):
    return jsonify({'error': 'Internal server error. Please try again.'}), 500

# ==================== MAIN EXECUTION ====================
if __name__ == '__main__':
    # Initialize database and create test user
    try:
        auth_system.init_db()
        # Create test user if not exists
        auth_system.register('admin', 'password123', 'admin@example.com')
    except:
        pass  # User already exists or table exists
    
    print("🚀 Starting AI Code Review Assistant...")
    print("📍 Access the application at: http://localhost:5000")
    print("🔑 Default login: admin / password123")
    print("📝 Features: Bug Detection, Security Analysis, Code Quality, Optimization")
    print("⏹️  Press Ctrl+C to stop the server")
    
    try:
        app.run(debug=True, host='0.0.0.0', port=5000)
    except KeyboardInterrupt:
        print("\n👋 Server stopped. Thank you for using AI Code Review Assistant!")